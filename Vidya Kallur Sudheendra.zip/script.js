const Books =[
   {
      "id":1,
      "title": "The Universe and Dr. Einstein",
      "year": 2005,
      "published": true
  
  },
  {
      "id":2,
      "title": "Einstein on politics",
      "year": 2013,
      "published": true
  },
  {
      "id":3,
      "title": "Einstein versus the physical review",
      "year": 2005,
      "published": true
  },
  {
      "id":4,
      "title": "Einstein on peace",
      "year": 2017,
      "published": true
  },
  {
      "id":5,
      "title": "Einstein: The life and times",
      "year": 2022,
      "author": "Ronald Clark",
      "published": false
  }]

function prnt(TXT)
{
   console.log(TXT); 
}

function dash()
{
   console.log("----------###-----------");
}

const bookPub =Books.filter(function(book){

   return book.published === true; // here we are returning the books in whcih published is true, keep in mind we are using === here
})

console.log(bookPub);

function myFunction() {
   document.getElementById("paper").innerHTML ;
 }



